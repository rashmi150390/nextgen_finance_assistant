# agents/kernel.py
import logging
import ollama
from typing import Optional

logger = logging.getLogger(__name__)


class ChatService:
    def __init__(self, model_name: str, timeout: Optional[int] = None):
        self.model_name = model_name
        self.timeout = timeout

    def complete_chat(self, prompt: str) -> str:
        """Call Ollama chat and return textual content.

        Raises RuntimeError if the Ollama call fails so callers can
        translate that into a 5xx/503 response.
        """
        try:
            # Call ollama.chat; different ollama client versions may return
            # different shapes. Be defensive when extracting content.
            result = ollama.chat(
                model=self.model_name,
                messages=[{"role": "user", "content": prompt}],
            )

            # Common response shapes:
            # - result.get("content")
            # - {"choices": [{"message": {"content": "..."}}]}
            if isinstance(result, dict):
                if "content" in result and result["content"]:
                    return result["content"]
                # choices -> message -> content
                choices = result.get("choices")
                if choices and isinstance(choices, (list, tuple)) and len(choices) > 0:
                    first = choices[0]
                    # try nested keys defensively
                    msg = first.get("message") if isinstance(first, dict) else None
                    if msg and isinstance(msg, dict) and msg.get("content"):
                        return msg.get("content")
                    if first.get("content"):
                        return first.get("content")

            # Fallback: convert whole result to string
            return str(result)

        except Exception as e:
            logger.exception("Ollama chat failed for model %s", self.model_name)
            raise RuntimeError(f"LLM chat failed: {e}") from e


class Kernel:
    def get_service(self, model_name: str = "mistral:7b-instruct") -> ChatService:
        return ChatService(model_name)


kernel = Kernel()