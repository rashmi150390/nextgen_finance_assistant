# agents/salary_agent.py
from agents.kernel import kernel
from agents.rag_agent import build_context

def decode_salary(query: str, model="mistral"):
    context = build_context(query)
    prompt = f"""
You are an Indian salary slip decoding agent.
User question: {query}
Relevant financial documents:
{context}
Explain salary components (Basic, HRA, PF, PT, TDS, Net Salary)
in simple conversational Indian English.
"""
    chat = kernel.get_service(model)
    response = chat.complete_chat(prompt)
    return str(response)