from agents.kernel import kernel
from utils.rag_utils import retrieve_faiss_chunks

def goal_agent(question: str, model: str):
    """
    Handles goal-based financial planning (car, house, retirement corpus)
    """
    context = retrieve_faiss_chunks(question, k=5)
    prompt = f"""
You are a goal-based financial assistant. Use the following context (salary, investments, expenses):
{context}

Provide a savings plan, timeline, and tax-saving recommendations.
Answer the user question: {question}
"""
    chat = kernel.get_service(model)
    response = chat.complete_chat(prompt)
    return str(response)