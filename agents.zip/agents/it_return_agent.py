from agents.kernel import kernel
from utils.rag_utils import retrieve_faiss_chunks

def it_return_planner(question: str, model: str):
    """
    Handles IT Return queries using uploaded salary slips, bank statements, and investments
    """
    context = retrieve_faiss_chunks(question, k=5)
    prompt = f"""
You are a friendly Indian financial assistant. Use the following context (salary slips, bank statements, investments):
{context}

Help the user with IT Return queries, deductions, and checklist.
Answer the user's question clearly and step-by-step:
{question}
"""
    chat = kernel.get_service(model)
    response = chat.complete_chat(prompt)
    return str(response)