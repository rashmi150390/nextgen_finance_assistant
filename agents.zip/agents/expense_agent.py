from agents.kernel import kernel
from utils.rag_utils import retrieve_faiss_chunks

def expense_agent(question: str, model: str):
    """
    Handles expense analysis, categorization, overspending alerts, and budgeting suggestions
    """
    context = retrieve_faiss_chunks(question, k=5)
    prompt = f"""
You are a friendly finance assistant. Use the following bank/credit card context:
{context}

Analyze expenses, categorize them, highlight overspending, and suggest budgeting improvements.
Answer the user question: {question}
"""
    chat = kernel.get_service(model)
    response = chat.complete_chat(prompt)
    return str(response)