from agents.kernel import kernel
from utils.rag_utils import retrieve_faiss_chunks

def general_agent(question: str, model: str):
    """
    Handles general finance queries like "What is HRA?", "What are ELSS benefits?", etc.
    """
    context = retrieve_faiss_chunks(question, k=5)
    prompt = f"""
You are a friendly Indian financial assistant. Use the following context:
{context}

Answer the user's finance question clearly and simply:
{question}
"""
    chat = kernel.get_service(model)
    response = chat.complete_chat(prompt)
    return str(response)