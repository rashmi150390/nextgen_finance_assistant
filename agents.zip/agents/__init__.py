# agents/__init__.py

"""Public imports for agents package.

Expose the actual function names implemented in the individual modules so
imports like `from agents.salary_agent import decode_salary` work when the
package is imported as a whole.
"""

# Import actual functions implemented in modules
from .salary_agent import decode_salary
from .expense_agent import expense_agent
from .goal_agent import goal_agent
from .it_return_agent import it_return_planner
from .general_agent import general_agent

# Expose kernel
from .kernel import kernel

# Example usage:
# from agents import decode_salary, expense_agent, goal_agent, it_return_planner, kernel