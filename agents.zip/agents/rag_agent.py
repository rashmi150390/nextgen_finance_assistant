from rag.retriever import rag_query

def build_context(query: str, top_k=5):
    """Fetch relevant documents using FAISS RAG."""
    docs = rag_query(query, top_k=top_k)
    context_blob = "\n\n---DOCUMENT---\n\n".join(docs)
    return context_blob