import faiss
from sentence_transformers import SentenceTransformer
import numpy as np
import pdfplumber
import pandas as pd
import logging
import os
from typing import Union, List

logger = logging.getLogger(__name__)

# Embedding model and FAISS index
embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
EMB_DIM = 384
faiss_index = faiss.IndexFlatL2(EMB_DIM)  # adjust dim if using another model

# Store mapping from index -> chunk text
faiss_text_store: List[str] = []


def chunk_text(text: str, chunk_size: int = 1000, overlap: int = 200) -> List[str]:
    """Split text into character chunks with an overlap to avoid cutting sentences abruptly."""
    if not text:
        return []
    chunks: List[str] = []
    start = 0
    text_len = len(text)
    while start < text_len:
        end = min(start + chunk_size, text_len)
        chunks.append(text[start:end])
        if end == text_len:
            break
        start = max(0, end - overlap)
    return chunks


def file_to_text(file: Union[str, os.PathLike, object]) -> str:
    """Read text from a PDF or CSV. Accepts a path or a file-like object.

    Returns an empty string on failure or unsupported types.
    """
    try:
        name = getattr(file, 'name', None) or (str(file) if isinstance(file, (str, os.PathLike)) else None)
        if name and name.lower().endswith('.pdf'):
            if isinstance(file, (str, os.PathLike)):
                pdf = pdfplumber.open(str(file))
            else:
                pdf = pdfplumber.open(file)
            with pdf:
                text = "".join([p.extract_text() or "" for p in pdf.pages])
            return text
        elif name and name.lower().endswith('.csv'):
            if isinstance(file, (str, os.PathLike)):
                df = pd.read_csv(str(file))
            else:
                df = pd.read_csv(file)
            return df.to_csv(index=False)
        else:
            return ""
    except Exception as e:
        logger.exception("Failed to read file %s: %s", getattr(file, 'name', str(file)), e)
        return ""


def add_file_to_faiss(file, chunk_size: int = 1000, overlap: int = 200) -> bool:
    """Extract text from `file`, chunk it, embed and add to FAISS index.

    Returns True on success, False on failure or if no text extracted.
    """
    text = file_to_text(file)
    if not text:
        logger.warning("No text extracted from file %s", getattr(file, 'name', str(file)))
        return False

    chunks = chunk_text(text, chunk_size=chunk_size, overlap=overlap)
    if not chunks:
        logger.warning("No chunks created for file %s", getattr(file, 'name', str(file)))
        return False

    try:
        # Request numpy output for easier conversion and FAISS compatibility
        embeddings = embedding_model.encode(chunks, convert_to_numpy=True, show_progress_bar=False)
        if embeddings.dtype != np.float32:
            embeddings = embeddings.astype(np.float32)
        faiss_index.add(embeddings)
        faiss_text_store.extend(chunks)
        return True
    except Exception as e:
        logger.exception("Failed to encode/add embeddings for file %s: %s", getattr(file, 'name', str(file)), e)
        return False


def retrieve_faiss_chunks(query: str, k: int = 5) -> str:
    """Return concatenated top-k retrieved text chunks for `query`.

    If the index is empty, returns an empty string.
    """
    if faiss_index.ntotal == 0 or len(faiss_text_store) == 0:
        logger.info("FAISS index is empty, nothing to retrieve")
        return ""

    k = int(min(k, faiss_index.ntotal))
    q_emb = embedding_model.encode([query], convert_to_numpy=True, show_progress_bar=False)
    if q_emb.dtype != np.float32:
        q_emb = q_emb.astype(np.float32)

    D, I = faiss_index.search(q_emb, k)
    results: List[str] = []
    for idx in I[0]:
        if 0 <= idx < len(faiss_text_store):
            results.append(faiss_text_store[idx])
    return " ".join(results)