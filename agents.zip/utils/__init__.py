# utils/__init__.py

# Expose RAG utility functions for easier imports
from .rag_utils import add_file_to_faiss, retrieve_faiss_chunks

# Now you can do:
# from utils import add_file_to_faiss, retrieve_faiss_chunks