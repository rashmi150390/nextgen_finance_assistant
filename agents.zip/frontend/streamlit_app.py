import sys
import os

# Add project root to Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st
import requests
import pandas as pd
import matplotlib.pyplot as plt
from utils.rag_utils import add_file_to_faiss, retrieve_faiss_chunks

st.set_page_config(page_title="Next-Gen Financial Assistant", layout="wide")
st.title("💰 Next-Gen Financial Assistant (India)")

# --- Sidebar Settings ---
st.sidebar.header("Settings")
model_option = st.sidebar.selectbox("Select AI Model:", ["mistral:7b-instruct", "llama3:8b"])
task_option = st.sidebar.radio("Select Task:", ["Salary", "Expenses", "Tax", "Goals", "General Finance", "IT Return"])

# --- File Upload ---
uploaded_files = st.file_uploader(
    "Upload your salary slips, bank statements, and investments (PDF/CSV)", 
    type=["pdf", "csv"], 
    accept_multiple_files=True
)

if uploaded_files:
    for file in uploaded_files:
        add_file_to_faiss(file)

# --- User Query ---
query = st.text_area(f"Enter your query for {task_option}:")

if st.button("Submit") and query.strip():
    endpoint_map = {
        "Salary": "salary",
        "Expenses": "expenses",
        "Tax": "tax",
        "Goals": "goals",
        "General Finance": "general",
        "IT Return": "it_return"
    }
    url = f"http://127.0.0.1:9001/{endpoint_map[task_option]}?q={query}&model={model_option}"

    try:
        response = requests.get(url)
        if response.status_code == 200:
            answer = response.json().get("answer", "No answer returned")
            st.markdown("### 💡 Answer:")
            st.write(answer)
        else:
            st.error(f"Error: {response.status_code}")
    except Exception as e:
        st.error(f"Failed to reach backend: {e}")

# --- Dynamic Visualizations ---
def plot_expenses(context_text):
    try:
        from io import StringIO
        df = pd.read_csv(StringIO(context_text))
        if "Category" in df.columns and "Amount" in df.columns:
            category_totals = df.groupby("Category")["Amount"].sum()
            fig, ax = plt.subplots()
            ax.pie(category_totals, labels=category_totals.index, autopct='%1.1f%%', startangle=140)
            ax.set_title("Monthly Expenses Breakdown")
            st.pyplot(fig)
    except:
        st.info("Expense data not structured. Showing text instead.")
        st.text(context_text[:2000])

def plot_goals(context_text):
    import re
    months, savings = [], []
    for line in context_text.splitlines():
        match = re.match(r"(\w+),\s*(\d+)", line)
        if match:
            months.append(match.group(1))
            savings.append(int(match.group(2)))
    if months and savings:
        fig, ax = plt.subplots()
        ax.plot(months, savings, marker='o', linestyle='-', color='green')
        ax.set_xlabel("Month")
        ax.set_ylabel("Savings Accumulated (₹)")
        ax.set_title("Goal Savings Timeline")
        st.pyplot(fig)
    else:
        st.info("No structured goal data found. Displaying text context instead.")
        st.text(context_text[:2000])

def plot_salary(context_text):
    try:
        from io import StringIO
        df = pd.read_csv(StringIO(context_text))
        components = ["Basic", "HRA", "PF", "ProfessionalTax", "IncomeTaxTDS"]
        if all(col in df.columns for col in components):
            st.dataframe(df)
            fig, ax = plt.subplots()
            ax.bar(components, [df[comp].sum() for comp in components], color='skyblue')
            ax.set_title("Salary Components Summary")
            st.pyplot(fig)
        else:
            st.text(context_text[:2000])
    except:
        st.text(context_text[:2000])

# Visualize based on selected tab
if query.strip():
    context_text = retrieve_faiss_chunks(query, k=5)
    if task_option == "Expenses":
        plot_expenses(context_text)
    elif task_option == "Goals":
        plot_goals(context_text)
    elif task_option == "Salary":
        plot_salary(context_text)
