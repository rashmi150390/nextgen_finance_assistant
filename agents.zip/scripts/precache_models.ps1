# scripts/precache_models.ps1
# Activate the venv and pre-download embedding model(s) to Hugging Face cache

$venv = "C:/Users/rashmi.anand.jathan/Desktop/Hackathon/nextgen_finance_assistant/venv/Scripts/Activate.ps1"
& $venv

# Run the python precache script
python .\scripts\precache_models.py
