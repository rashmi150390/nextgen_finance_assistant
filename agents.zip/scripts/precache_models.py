from sentence_transformers import SentenceTransformer

models = [
    "sentence-transformers/all-MiniLM-L6-v2",
]

for m in models:
    print(f"Pre-downloading {m}...")
    SentenceTransformer(m)

print("Done. Models are cached locally.")
