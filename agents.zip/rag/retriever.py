import faiss
import json
import numpy as np
from sentence_transformers import SentenceTransformer
import logging
import os

logger = logging.getLogger(__name__)

# Use a lightweight embedding model suitable for CPU-only machines
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
INDEX_PATH = os.path.join("rag", "faiss_index.bin")
DOCS_PATH = os.path.join("rag", "faiss_docs.json")


def _load_model():
    try:
        # Prefer local files only (avoid network at runtime). If not cached, fall back to normal load.
        return SentenceTransformer(MODEL_NAME, local_files_only=True)
    except Exception:
        logger.info("Local model not found in cache; attempting online download for %s", MODEL_NAME)
        return SentenceTransformer(MODEL_NAME)


def _load_index_and_docs():
    if not os.path.exists(INDEX_PATH) or not os.path.exists(DOCS_PATH):
        logger.warning("FAISS index or docs not found: %s, %s", INDEX_PATH, DOCS_PATH)
        return None, []
    try:
        index = faiss.read_index(INDEX_PATH)
        with open(DOCS_PATH, "r", encoding="utf-8") as f:
            docs = json.load(f)
        return index, docs
    except Exception as e:
        logger.exception("Failed to load FAISS index or docs: %s", e)
        return None, []


# Lazy-load resources
MODEL = None
INDEX, DOCS = None, []


def rag_query(query_text, top_k=5):
    global MODEL, INDEX, DOCS
    if MODEL is None:
        MODEL = _load_model()
    if INDEX is None:
        INDEX, DOCS = _load_index_and_docs()

    if INDEX is None or len(DOCS) == 0:
        return []

    # Encode query to numpy float32
    q_emb = MODEL.encode([query_text], convert_to_numpy=True, show_progress_bar=False)
    if q_emb.dtype != np.float32:
        q_emb = q_emb.astype(np.float32)

    # Ensure shape is (1, dim)
    D, I = INDEX.search(q_emb, int(min(top_k, INDEX.ntotal)))
    results = []
    for idx in I[0]:
        if 0 <= idx < len(DOCS):
            results.append(DOCS[idx])
    return results