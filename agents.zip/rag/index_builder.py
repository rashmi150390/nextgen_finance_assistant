from sentence_transformers import SentenceTransformer
import faiss
import os
import json
import numpy as np
import logging

logger = logging.getLogger(__name__)

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
INDEX_PATH = os.path.join("rag", "faiss_index.bin")
DOCS_PATH = os.path.join("rag", "faiss_docs.json")


def _load_model():
    try:
        return SentenceTransformer(MODEL_NAME, local_files_only=True)
    except Exception:
        logger.info("Local model not found; downloading %s", MODEL_NAME)
        return SentenceTransformer(MODEL_NAME)


def load_docs():
    docs = []
    for root, dirs, files in os.walk("rag_docs"):
        for f in files:
            if f.endswith(".json") or f.endswith(".txt") or f.endswith(".csv"):
                with open(os.path.join(root, f), "r", encoding="utf-8", errors="ignore") as file:
                    docs.append(file.read())
    return docs


def build_index():
    model = _load_model()
    docs = load_docs()
    if not docs:
        logger.warning("No docs found in rag_docs to index")
        return

    # Encode to numpy and ensure float32
    embeddings = model.encode(docs, convert_to_numpy=True, show_progress_bar=True)
    if embeddings.dtype != np.float32:
        embeddings = embeddings.astype(np.float32)

    # Build FAISS index
    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(embeddings)

    # Ensure rag dir exists
    os.makedirs(os.path.dirname(INDEX_PATH), exist_ok=True)

    # Save index and docs
    faiss.write_index(index, INDEX_PATH)
    with open(DOCS_PATH, "w", encoding="utf-8") as f:
        json.dump(docs, f)

    print("FAISS index built successfully!")


if __name__ == "__main__":
    build_index()