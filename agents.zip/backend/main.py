from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import os
from agents.salary_agent import decode_salary
from agents.expense_agent import expense_agent
from agents.it_return_agent import it_return_planner
from agents.goal_agent import goal_agent
from agents.general_agent import general_agent
from agents.kernel import kernel

app = FastAPI()
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)


def _call_agent(func, q: str, model: str):
    try:
        return {"answer": func(q, model)}
    except RuntimeError as e:
        # raised by agents when LLM is unavailable
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/salary")
def salary(q: str, model: str = "mistral:7b-instruct"):
    return _call_agent(decode_salary, q, model)


@app.get("/expenses")
def expenses(q: str, model: str = "mistral:7b-instruct"):
    return _call_agent(expense_agent, q, model)


@app.get("/tax")
def tax(q: str, model: str = "mistral:7b-instruct"):
    return _call_agent(it_return_planner, q, model)


@app.get("/goals")
def goals(q: str, model: str = "mistral:7b-instruct"):
    return _call_agent(goal_agent, q, model)


@app.get("/general")
def general(q: str, model: str = "mistral:7b-instruct"):
    return _call_agent(general_agent, q, model)


@app.get("/it_return")
def it_return(q: str, model: str = "mistral:7b-instruct"):
    return _call_agent(it_return_planner, q, model)


@app.get("/health")
def health():
    """Simple health check for Ollama and RAG index existence."""
    status = {"ollama": False, "rag_index": False}
    # Check rag index file
    status["rag_index"] = os.path.exists(os.path.join("rag", "faiss_index.bin"))

    # Check Ollama by attempting a lightweight ping via kernel
    try:
        svc = kernel.get_service("mistral")
        # small non-sensitive prompt
        svc.complete_chat("ping")
        status["ollama"] = True
    except Exception:
        status["ollama"] = False

    return status